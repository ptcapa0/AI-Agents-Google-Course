Coding Agent guidance:
{%- if cookiecutter.is_adk %}
{{ cookiecutter.adk_cheatsheet }}
{%- endif %}
{{ cookiecutter.llm_txt }}